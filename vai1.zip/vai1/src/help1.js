const help1 = (prefix) => {
	return `
┃MENU EM ATUALIZAÇÃO ⚠️
┣QUALQUER COISA
┣CHAME O DONO
┣wa.me/+558994263981`
}
exports.help1 = help1


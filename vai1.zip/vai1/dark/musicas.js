const musicas = () => { 
	return `           
──────────────────
*YOUTUBE MUSIC*
──────────────────
_*COMANDOS:*_
──────────────────

1• *${prefix}hylander*
2• *${prefix}nikeb*
3• *${prefix}BanhoDeLeite*
4• *${prefix}AkDoFlamengo*
5• *${prefix}Nemo*
6• *${prefix}kalidade*
7• *${prefix}macaverde*
8• *${prefix}m4*
9• *${prefix}cmgremio*
10• *${prefix}cmflamengo*

──────────────────
『 SUGESTÃO DE MSC 』
           
_*wa.me/+558994263981*_
──────────────────`
}
exports.musicas = musicas
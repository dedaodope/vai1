[
    {
	"teks": "CPF GERADO: 884.506.490-56",
	"image": "https://i.ibb.co/tMh2xTv/20210220-164937.jpg"
    },
    {
	"teks": "CPF GERADO: 974.796.180-69",
	"image": "https://i.ibb.co/YtdRHwG/20210220-165118.jpg"
    },
    {
	"teks": "CPF GERADO: 187.616.300-39",
	"image": "https://i.ibb.co/9gm51cN/20210220-165211.jpg"
    },
    {
	"teks": "CPF GERADO: 429.449.510-33",
	"image": "https://i.ibb.co/cksjh66/20210220-165321.jpg"
    },
    {
    "teks": "CPF GERADO: 315.970.360-64",
    "image": "https://i.ibb.co/r2kTTMv/20210220-165415.jpg"
    },
    {
    "teks": "CPF GERADO: 170.609.870-70",
    "image": "https://i.ibb.co/mhSxdQD/20210220-165627.jpg"
    },
    {
    "teks": "CPF GERADO: 171.618.810-56",
    "image": "https://i.ibb.co/w6rWVtR/20210220-165744.jpg"
    },
    {
    "teks": "CPF GERADO: 647.518.770-46",
    "image": "https://i.ibb.co/4Fj0mkD/20210220-165904.jpg"
    },
    {
    "teks": "CPF GERADO: 278.383.240-25",
    "image": "https://i.ibb.co/SBrr0LZ/20210220-165951.jpg"
    },
    {
    "teks": "CPF GERADO: 400.138.290-33",
    "image": "https://i.ibb.co/rtsC3H2/20210220-170059.jpg"
    },
    {
    "teks": "CPF GERADO: 791.164.510-82",
    "image": "https://i.ibb.co/82tsDwS/20210220-170153.jpg"
    },
    {
    "teks": "CPF GERADO: 483.059.070-07",
    "image": "https://i.ibb.co/zHPDGmt/20210220-170238.jpg"
    },
    {
    "teks": "CPF GERADO: 707.888.020-03",
    "image": "https://i.ibb.co/mT8g6yN/20210220-170319.jpg"
    },
    {
    "teks": "CPF GERADO: 239.006.510-43",
    "image": "https://i.ibb.co/rQqFV2f/20210220-170436.jpg"
    },
    {
	"teks": "CPF GERADO: 884.506.490-56",
	"image": "https://i.ibb.co/tMh2xTv/20210220-164937.jpg"
    },
    {
	"teks": "CPF GERADO: 974.796.180-69",
	"image": "https://i.ibb.co/YtdRHwG/20210220-165118.jpg"
    },
    {
	"teks": "CPF GERADO: 187.616.300-39",
	"image": "https://i.ibb.co/9gm51cN/20210220-165211.jpg"
    },
    {
	"teks": "CPF GERADO: 429.449.510-33",
	"image": "https://i.ibb.co/cksjh66/20210220-165321.jpg"
    },
    {
    "teks": "CPF GERADO: 315.970.360-64",
    "image": "https://i.ibb.co/r2kTTMv/20210220-165415.jpg"
    },
    {
    "teks": "CPF GERADO: 170.609.870-70",
    "image": "https://i.ibb.co/mhSxdQD/20210220-165627.jpg"
    },
    {
    "teks": "CPF GERADO: 171.618.810-56",
    "image": "https://i.ibb.co/w6rWVtR/20210220-165744.jpg"
    },
    {
    "teks": "CPF GERADO: 647.518.770-46",
    "image": "https://i.ibb.co/4Fj0mkD/20210220-165904.jpg"
    },
    {
    "teks": "CPF GERADO: 278.383.240-25",
    "image": "https://i.ibb.co/SBrr0LZ/20210220-165951.jpg"
    },
    {
    "teks": "CPF GERADO: 400.138.290-33",
    "image": "https://i.ibb.co/rtsC3H2/20210220-170059.jpg"
    },
    {
    "teks": "CPF GERADO: 791.164.510-82",
    "image": "https://i.ibb.co/82tsDwS/20210220-170153.jpg"
    },
    {
    "teks": "CPF GERADO: 483.059.070-07",
    "image": "https://i.ibb.co/zHPDGmt/20210220-170238.jpg"
    },
    {
    "teks": "CPF GERADO: 707.888.020-03",
    "image": "https://i.ibb.co/mT8g6yN/20210220-170319.jpg"
    },
    {
    "teks": "CPF GERADO: 239.006.510-43",
    "image": "https://i.ibb.co/rQqFV2f/20210220-170436.jpg"
    }
]

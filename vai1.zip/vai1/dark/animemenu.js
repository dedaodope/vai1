const animmenu = () => { 
	return `           
──────────────────
*COMANDOS DE ANIME*
──────────────────
    『 TRAILERS 』
──────────────────
𝘋𝘐𝘎𝘐𝘛𝘌 𝘖 𝘊𝘖𝘔𝘈𝘕𝘋𝘖 𝘊𝘖𝘔 𝘖 𝘓𝘐𝘕𝘒 

𝘌𝘟: .𝘯 𝘩𝘵𝘵𝘱𝘴://...

*TOKYO REVENGERS*

${prefix}n https://youtu.be/2Ny3YIZWQM0

*Zombie Land Saga REVENGE*

${prefix}n https://youtu.be/6mBe3dyV3Nc

*JORAN THE PRINCESS OF SNOW AND BLOOD*

${prefix}n https://youtu.be/6W1GnrUcgXQ

*ODDTAXI | TRAILER*

${prefix}n https://youtu.be/y-UyPgs3hyQ

──────────────────
    『 IMAGENS 』
──────────────────

*${prefix}rize*
*${prefix}minato*
*${prefix}boruto*
*${prefix}hinata*
*${prefix}sasuke*
*${prefix}sakura*
*${prefix}naruto*


──────────────────
    『 GUSTAVO 』
──────────────────`
}
exports.animmenu = animmenu
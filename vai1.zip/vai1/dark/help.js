const help = () => { 
	return `
╔══🛸〘 INFO 〙🛸══
║
╠Coé? 
║
╠➥ 【Gustavo】
╠➥ *0.1*
╠➥ 𝐃𝐎𝐍𝐎: 【Gustavo】  🤏😎
╠➥ *wa.me/+55899426398181*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══🛸〘 NOVIDADES 〙🛸══
║
║1 *${prefix}msc*
║2 *${prefix}Comandos de voz*
║3 *${prefix}meme [corrigido]*
║4 *${prefix}comandos sem prefix*
║5 *${prefix}gbin [premium]*
║5 *${prefix}pack [premium]*
║6 *${prefix}destrava [premium]*
║7 *${prefix}gpessoa [premium]*
║8 *${prefix}wame*
║9 *${prefix}spamcall*
║10 *${prefix}play (nome da msc)*
║
╠══🛸〘 MENU 〙🛸══
║
║11 *${prefix}figu*
║12 *${prefix}toimg*
║13 *${prefix}darkjokes (memes aleatórios)*
║14 *${prefix}memeindo*
║15 *${prefix}tts*
║16 *${prefix}lolih [on]*
║17 *${prefix}nsfwloli [off]*
║18 *${prefix}url2img*
║19 *${prefix}leens [na legenda]*
║20 *${prefix}wait [na legenda]*
║21 *${prefix}setprefix*
║
╠══🛸〘 OUTROS 〙🛸══
║
║22 *${prefix}linkgp*
║23 *${prefix}simih [1/0]*
║24 *${prefix}marcar*
║25 *${prefix}add [@]*
║26 *${prefix}banir [@]*
║27 *${prefix}promover [@]*
║28 *${prefix}rebaixar*
║29 *${prefix}admins*
║30 *${prefix}marcar2*
║31 *${prefix}bc [texto]* (ele faz uma ™)
║32 *${prefix}marcar3*
║33 *${prefix}bloqueados*
║34 *${prefix}bloquear [@]*
║35 *${prefix}desbloquear [@]*
║36 *${prefix}limpar*
║37 *${prefix}bc [ *texto* ]*
║38 *${prefix}bemvindo [1/0]*
║39 *${prefix}clonar [@]*
║40 *${prefix}help1*
║41 *${prefix}dono*
║42 *${prefix}owner*
║43 *${prefix}tts [texto]*
║44 *${prefix}setnome*
║45 *${prefix}termux*
║46 *${prefix}setfoto*
║47 *${prefix}grupoinfo*
║48 *${prefix}ytmp4*
║49 *${prefix}bomdia*
║50 *${prefix}boanoite*
║51 *${prefix}marcar*
║52 *${prefix}marcar2*
║53 *${prefix}marcar3*
║
╠══🛸〘 IMAGENS 〙🛸══
║
║54 *${prefix}loli* [off]
║55 *${prefix}loli1*
║56 *${prefix}hentai*
║57 *${prefix}dono*
║58 *${prefix}porno*
║59 *${prefix}boanoite*
║60 *${prefix}bomdia*
║61 *${prefix}boatarde*
║62 *${prefix}mia [aleatórias]*
║63 *${prefix}rize [aleatórias]*
║64 *${prefix}minato [aleatórias]*
║65 *${prefix}boruto [aleatórias]*
║66 *${prefix}hinata [aleatórias]*
║67 *${prefix}sasuke [aleatórias]*
║68 *${prefix}sakura [aleatórias]*
║69 *${prefix}naruto [aleatórias]*
║70 *${prefix}meme*   
║71 *${prefix}lofi*
║72 *${prefix}malkova*
║73 *${prefix}canal*
║74 *${prefix}nsfwloli1*
║75 *${prefix}reislin*
║
╠══🛸〘 INTELIGÊNCIA IA 〙🛸══
║
║76 *${prefix}simih 1 (para ativar)*
║77 *${prefix}simih 0 (para desativar)*
║ *${prefix}simi (sua mensagem)*
║
╠══🛸〘 EM TESTE 〙🛸══
║
║78 *${prefix}*
║79 *${prefix}*
║80 *${prefix}*
║
╠══🛸〘 PREMIUM 〙🛸══
║
║81 *${prefix}dado*
║82 *${prefix}cekvip*
║83 *${prefix}premiumlist*
║84 *${prefix}delete*
║85 *${prefix}modapk*
║86 *${prefix}indo10*
║87 *${prefix}daftarvip [para virar Premium]*
║88 *${prefix}qrcode*
║89 *${prefix}chentai*
║90 *${prefix}gcpf*
║91 *${prefix}gbin*
║92 *${prefix}pack*
║93 *${prefix}destrava*
║94 *${prefix}gpessoa*
║
╠══🛸〘 GRUPO 〙🛸══
║
║95 *${prefix}banir*
║96 *${prefix}leveling [on/off]*
║97 *${prefix}level*
║98 *${prefix}add*
║99 *${prefix}promover*
║100 *${prefix}setfoto [na legenda]*
║101 *${prefix}setname [texto]*
║102 *${prefix}rebaixar*
║103 *${prefix}admins*
║104 *${prefix}marcar*
║105 *${prefix}marcar2*
║106 *${prefix}marcar3*
║107 *${prefix}bemvindo [1/0]*
║108 *${prefix}grupoinfo*
║109 *${prefix}bomdia*
║110 *${prefix}boatarde*
║111 *${prefix}boanoite*
║112 *${prefix}setdesc*
║113 *${prefix}bug [sua mensagem]*
║
╠══🛸〘 ESPECIFICO DO BOT 〙🛸══
║
║114 *${prefix}bug [sua mensagem]*
║115 *${prefix}clonar [@]*
║116 *${prefix}dono*
║117 *${prefix}ping [ver velocidade do bot]*
║118 *${prefix}termux*
║119 *${prefix}gay [@]*
║120 *${prefix}wame*
║121 *${prefix}map (nome)*
║122 *${prefix}setppbot (marque uma img)*
║123 *${prefix}pinterest (nome)*
║124 *${prefix}desligar (so para o dono)*
║125 *${prefix}timer*
║
╠══🛸〘 MAIS ALGUNS 〙🛸══
║
║126 *${prefix}neko*
║127 *${prefix}ttp [texto]*
║128 *${prefix}testime*
║129 *${prefix}tomp3*
║130 *${prefix}modoanime [on/off]*
║131 *${prefix}modonsfw [on/off]*
║132 *${prefix}happymod [jogo/app]*
║133 *${prefix}rize*
║134 *${prefix}ytsearch*
║135 *${prefix}moddroid [jogo/app]*
║136 *${prefix}xvideos [titulo]**
║137 *${prefix}nomegp*
║138 *${prefix}darkjokes (memes aleatórios)*
║139 *${prefix}animecry*
║140 *${prefix}gay1*
║141 *${prefix}next*
║142 *${prefix}alerta*
║143 *${prefix}belle [img aleatórias]*
║144 *${prefix}pronomeneu [texto]*
║144 *${prefix}hobby*
║
╠══🛸〘 COMANDOS DE VOZ 〙🛸══
║
║145 *${prefix}ola*
║146 *${prefix}bv*
║147 *${prefix}tchau*
║148 *${prefix}bem*
║149 *${prefix}a*
║150 *${prefix}fdp*
║151 *${prefix}onich*
║152 *${prefix}beat1*
║153 *${prefix}glub*
║
╠══🛸〘 OUTROS /2 〙🛸══
║
║154 *${prefix}antilink [1/0]*
║155 *${prefix}brainly [pergunta]*
║156 *${prefix}antiracismo [on/off]*
║157 *${prefix}setnomebot*
║158 *${prefix}meme*
║159 *${prefix}musicas*
║
╠══🛸〘 YT MUSIC 〙🛸══
║
╠══NOTA »
║menu completo em .msc
╠════════════════════
║
║160 *${prefix}hylander*
║161 *${prefix}nikeb*
║162 *${prefix}BanhoDeLeite*
║163 *${prefix}AkDoFlamengo*
║164 *${prefix}Nemo*
║165 *${prefix}kalidade*
║166 *${prefix}macaverde*
║167 *${prefix}m4*
║168 *${prefix}cmgremio*
║169 *${prefix}cmflamengo*
║
║
╠══🛸〘 HACKER MENU 〙🛸══
║
║170 *${prefix}fbcheker*
║171 *${prefix}hackfb*
║172 *${prefix}bruteforcefb*
║173 *${prefix}toolsphishing*
║174 *${prefix}terkeytermux*
║175 *${prefix}socialfishv2*
║176 *${prefix}tool*
║
╠══🛸〘 STICKER MENU 〙🛸══
║
║177 *${prefix}animecry* 
║178 *${prefix}hubgif*
║179 *${prefix}blowgif* 🔞
║180 *${prefix}shota*
║181 *${prefix}hentaifig* 🔞
║182 *${prefix}nekofig* 🔞
║183 *${prefix}lolifig*
║
╠══🛸〘 INTERATIVOS 〙🛸══
║
╠══NOTA »
║Mandar a msg sem o prefixo
╠════════════════════
║
║184 *bah*
║185 *oii*
║186 *bv*
║187 *canta ai bot*
║188 *grita*
║189 *digita*
║190 *machista*
║
╠══🛸〘 OUTROS /3 〙🛸══
║
║191 *${prefix}atris* 🔞
║192 *${prefix}animemenu*
║
╠══🛸〘 CMDS DE VÍDEO 〙🛸══
║
╠══EDITS »
║_*Shitposter*_
╠════════
║
║192 *${prefix}shit1*
║193 *${prefix}shit2*
║194 *${prefix}shit3*
║195 *${prefix}shit4*
║
╠══EDITS »
║_*XXXTENTACIONS*_
╠═══════════════
║
║196 *${prefix}xxx1*
║197 *${prefix}xxx2*
║
╠══EDITS »
║_*VARIADAS*_
╠═══════════════
║
║198 *${prefix}teto1*
║199 *${prefix}edit1*
║200 *${prefix}edit2*
║201 *${prefix}edit3*
║202 *${prefix}edit4*
╠═══════════════
║
║ *MAIS COMANDOS*
║ *PRÓXIMA ATT*
║
╠══🛸〘 𝗗𝗢𝗡𝗢 〙🛸══
║
║ *NOME: 【Gustavo】⃖  🤏😎*
║ *INSTA: gustavo2krp*
║ *WPP: wa.me/+558994263981*
║
║
║
║
║
╚═〘 【Gustavo】 〙`
}

exports.help = help


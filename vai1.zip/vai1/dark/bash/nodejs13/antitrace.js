const antitrace = (prefix) => { 
	return `
	
	*Soluçao! Este recurso ainda está em desenvolvimento, aguarde a última atualização da versão Dark Bot*
	
[❗] *As últimas atualizações do WhatsApp Bot estão apenas no canal do Youtube : Darkkk*

⧿⧽ *Não se esqueça de se inscrever*
⧿⧽ *Ative os sinos*
⧿⧽ *Atenciosamente Dark*

`
}
exports.antitrace = antitrace

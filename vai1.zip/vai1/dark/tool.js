const tool = () => { 
	return `           
──────────────────
*TOOL HACKER TERMUX*
──────────────────
        『 𝕯𝖆𝖗𝖐 𝕭𝖔𝖙 』
──────────────────
apt-get install python3

apt-get install git

git clone https://github.com/AngelSecurityTeam/Cam-Hackers

pip3 install requests

cd Cam-Hackers

python3 cam-hackers.py
──────────────────
        『 𝕯𝖆𝖗𝖐 𝕭𝖔𝖙 』
──────────────────`
}
exports.tool = tool